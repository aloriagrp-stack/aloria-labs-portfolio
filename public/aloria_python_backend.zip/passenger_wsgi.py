import os
import sys

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

try:
    from mobile_server import app
    from a2wsgi import ASGIMiddleware

    class StripScriptNameMiddleware:
        def __init__(self, wsgi_app):
            self.wsgi_app = wsgi_app
        def __call__(self, environ, start_response):
            script_name = environ.get('SCRIPT_NAME', '')
            if script_name:
                environ['PATH_INFO'] = script_name + environ.get('PATH_INFO', '')
                environ['SCRIPT_NAME'] = ''
            return self.wsgi_app(environ, start_response)

    raw_application = ASGIMiddleware(app)
    application = StripScriptNameMiddleware(raw_application)

except Exception as e:
    import traceback
    err_tb = traceback.format_exc()
    def application(environ, start_response):
        start_response('500 Internal Server Error', [('Content-Type', 'text/html; charset=utf-8')])
        return [f'<h1>Aloria Hunter Backend Startup Error</h1><pre>{err_tb}</pre>'.encode('utf-8')]
